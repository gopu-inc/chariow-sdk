Chariow SDK

Official Node.js & TypeScript SDK for the Chariow API.

Build powerful e-commerce applications with Chariow using a modern and fully typed SDK.

---

Features

- Full TypeScript support
- Modern ESM compatible
- Simple API client
- Product API support
- HTML cleaning utilities
- Product models
- Lightweight and fast
- Works with Node.js, Bun and TSX

---

Installation

npm install chariow-sdk

---

Quick Start

import { Chariow }
from "chariow-sdk"

const api = new Chariow(
  process.env.CHARIOW_API_KEY!
)

const products =
  await api.products.list()

console.log(products)

---

Authentication

Generate your API key from your Chariow dashboard.

const api = new Chariow(
  "sk_xxxxx"
)

---

Products API

List Products

const products =
  await api.products.list()

console.log(products)

---

Get Product

const product =
  await api.products.get(
    "prd_xxx"
  )

console.log(product)

---

Product Model

The SDK automatically exposes helper getters.

const product =
  await api.products.get(
    "prd_xxx"
  )

console.log(product.name)
console.log(product.description)
console.log(product.thumbnail)
console.log(product.price)
console.log(product.isPublished)

---

Example Response

[
  {
    id: "prd_xxx",
    name: "My product",
    status: "published"
  }
]

---

Error Handling

try {

  const products =
    await api.products.list()

} catch (error) {

  console.error(error)

}

---

TypeScript Support

The SDK is fully typed.

import type {
  Product
} from "chariow-sdk"

---

Build

npm run build

---

Development

git clone https://github.com/gopu-inc/chariow-sdk.git

cd chariow-sdk

npm install

---

Project Structure

src/
 ├── client.ts
 ├── sdk.ts
 ├── errors.ts
 ├── models/
 ├── modules/
 ├── types/
 └── utils/

---

Requirements

- Node.js 18+
- TypeScript 5+

---

License

MIT

---

Official Links

- Website: https://chariow.com
- API: https://api.chariow.com
- Docs: https://chariow.dev/api-reference/introduction

---

Status

Currently supported:

- Products API

Coming soon:

- Orders API
- Customers API
- Checkout API
- Webhooks
- Store API
- Analytics API
